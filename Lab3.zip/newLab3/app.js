const canvas = document.getElementById('canvas');
const ctx = canvas.getContext('2d');
const W = canvas.width;
const H = canvas.height;

let pixels = [];
let ideal = null;


function $(id) {
  return document.getElementById(id);
}

function readNumber(id) {
  const text = $(id).value.trim();
  if (!/^-?\d+$/.test(text)) return null;
  return parseInt(text);
}



function build() {
  const algo = $('algo').value;
  logging = true;
  logRows = [];
  logHead = [];
  logNote = '';

  if (algo === 'circle') {
    const x0 = readNumber('x0');
    const y0 = readNumber('y0');
    const r = readNumber('r');
    if (x0 === null || y0 === null || r === null || r < 0) {
      $('error').textContent = 'Введите целые числа (R не меньше 0)';
      return;
    }
    pixels = bresenhamCircle(x0, y0, r);
    ideal = { circle: true, x0: x0, y0: y0, r: r };
  } else {
    const x1 = readNumber('x1');
    const y1 = readNumber('y1');
    const x2 = readNumber('x2');
    const y2 = readNumber('y2');
    if (x1 === null || y1 === null || x2 === null || y2 === null) {
      $('error').textContent = 'Введите целые числа';
      return;
    }
    if (algo === 'step') pixels = stepByStep(x1, y1, x2, y2);
    if (algo === 'dda') pixels = dda(x1, y1, x2, y2);
    if (algo === 'bres') pixels = bresenham(x1, y1, x2, y2);
    if (algo === 'castle') pixels = castlePitteway(x1, y1, x2, y2);
    if (algo === 'wu') pixels = wu(x1, y1, x2, y2);
    ideal = { circle: false, x1: x1, y1: y1, x2: x2, y2: y2 };
  }
  logging = false;
  $('error').textContent = '';

  chooseScale();
  draw();
  showTable();
}

function chooseScale() {
  let maxX = 1;
  let maxY = 1;
  for (const p of pixels) {
    maxX = Math.max(maxX, Math.abs(p.x));
    maxY = Math.max(maxY, Math.abs(p.y));
  }
  let s = Math.floor(Math.min(W / 2 / (maxX + 2), H / 2 / (maxY + 2)));
  s = Math.max(3, Math.min(60, s));
  $('scale').value = s;
}



function draw() {
  const s = Number($('scale').value);
  const ox = W / 2;
  const oy = H / 2;

  ctx.clearRect(0, 0, W, H);

  if (s >= 6) {
    ctx.strokeStyle = '#ddd';
    ctx.lineWidth = 1;
    ctx.beginPath();
    for (let k = -Math.ceil(W / s); k <= Math.ceil(W / s); k++) {
      ctx.moveTo(ox + (k + 0.5) * s, 0);
      ctx.lineTo(ox + (k + 0.5) * s, H);
    }
    for (let k = -Math.ceil(H / s); k <= Math.ceil(H / s); k++) {
      ctx.moveTo(0, oy - (k + 0.5) * s);
      ctx.lineTo(W, oy - (k + 0.5) * s);
    }
    ctx.stroke();
  }

  for (const p of pixels) {
    ctx.fillStyle = 'rgba(30, 80, 220, ' + p.a + ')';
    ctx.fillRect(ox + (p.x - 0.5) * s, oy - (p.y + 0.5) * s, s, s);
  }

  if ($('showIdeal').checked && ideal !== null) {
    ctx.strokeStyle = 'red';
    ctx.lineWidth = 1.5;
    ctx.setLineDash([6, 4]);
    ctx.beginPath();
    if (ideal.circle) {
      ctx.arc(ox + ideal.x0 * s, oy - ideal.y0 * s, ideal.r * s, 0, 2 * Math.PI);
    } else {
      ctx.moveTo(ox + ideal.x1 * s, oy - ideal.y1 * s);
      ctx.lineTo(ox + ideal.x2 * s, oy - ideal.y2 * s);
    }
    ctx.stroke();
    ctx.setLineDash([]);
  }

  ctx.strokeStyle = 'black';
  ctx.lineWidth = 1.5;
  ctx.beginPath();
  ctx.moveTo(0, oy);
  ctx.lineTo(W, oy);
  ctx.moveTo(ox, 0);
  ctx.lineTo(ox, H);
  ctx.stroke();

  ctx.fillStyle = 'black';
  ctx.font = '12px Arial';
  ctx.fillText('x', W - 12, oy - 6);
  ctx.fillText('y', ox + 6, 12);

  let step = 1;
  if (s < 25) step = 2;
  if (s < 12) step = 5;
  if (s < 6) step = 10;
  ctx.textAlign = 'center';
  for (let k = -Math.floor(W / 2 / s); k <= W / 2 / s; k += step) {
    if (k !== 0) ctx.fillText(k, ox + k * s, oy + 14);
  }
  ctx.textAlign = 'right';
  for (let k = -Math.floor(H / 2 / s); k <= H / 2 / s; k += step) {
    if (k !== 0) ctx.fillText(k, ox - 5, oy - k * s + 4);
  }
  ctx.fillText('0', ox - 5, oy + 14);
  ctx.textAlign = 'left';
}



function showTable() {
  $('note').textContent = logNote + '  Пикселей: ' + pixels.length;
  let html = '<div class="scroll"><table><tr>';
  for (const h of logHead) html += '<th>' + h + '</th>';
  html += '</tr>';
  for (const row of logRows.slice(0, 300)) {
    html += '<tr>';
    for (const cell of row) html += '<td>' + cell + '</td>';
    html += '</tr>';
  }
  html += '</table></div>';
  $('tableBox').innerHTML = html;
}


function measure(func) {
  func();
  let n = 10;
  while (true) {
    const start = performance.now();
    for (let i = 0; i < n; i++) func();
    const ms = performance.now() - start;
    if (ms >= 100) return (ms * 1000 / n).toFixed(1);
    n = n * 2;
  }
}

function runBench() {
  logging = false;
  const lines = [
    ['Пошаговый', stepByStep],
    ['ЦДА', dda],
    ['Брезенхем (отрезок)', bresenham],
    ['Кастл-Питвей', castlePitteway],
    ['Ву', wu]
  ];
  let html = '<table><tr><th>Алгоритм</th><th>отрезок 100 пикс., мкс</th><th>отрезок 1000 пикс., мкс</th></tr>';
  for (const item of lines) {
    const f = item[1];
    const t1 = measure(function () { f(0, 0, 100, 62); });
    const t2 = measure(function () { f(0, 0, 1000, 617); });
    html += '<tr><td>' + item[0] + '</td><td>' + t1 + '</td><td>' + t2 + '</td></tr>';
  }
  html += '</table><table><tr><th>Алгоритм</th><th>R = 50, мкс</th><th>R = 500, мкс</th></tr>';
  const c1 = measure(function () { bresenhamCircle(0, 0, 50); });
  const c2 = measure(function () { bresenhamCircle(0, 0, 500); });
  html += '<tr><td>Брезенхем (окружность)</td><td>' + c1 + '</td><td>' + c2 + '</td></tr></table>';
  $('benchBox').innerHTML = html;
  $('bench').textContent = 'Замерить ещё раз';
}



$('algo').addEventListener('change', function () {
  const isCircle = $('algo').value === 'circle';
  $('lineInputs').hidden = isCircle;
  $('circleInputs').hidden = !isCircle;
  build();
});
$('build').addEventListener('click', build);
$('scale').addEventListener('input', draw);
$('showIdeal').addEventListener('change', draw);
$('bench').addEventListener('click', function () {
  $('bench').textContent = 'Идёт замер...';
  setTimeout(runBench, 50);
});

build();
