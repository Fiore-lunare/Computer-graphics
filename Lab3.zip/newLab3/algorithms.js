let logging = false;
let logHead = [];
let logRows = [];
let logNote = '';

function addRow(...cells) {
  if (logging) logRows.push(cells);
}

function round(v) {
  return Math.round(v) + 0;
}


// 1.Пошаговый алгоритм: y = k*x + b
function stepByStep(x1, y1, x2, y2) {
  const pixels = [];
  const dx = x2 - x1;
  const dy = y2 - y1;
  if (dx === 0 && dy === 0) {
    pixels.push({ x: x1, y: y1, a: 1 });
    return pixels;
  }

  if (Math.abs(dx) >= Math.abs(dy)) {
    const k = dy / dx;
    const b = y1 - k * x1;
    const step = dx > 0 ? 1 : -1;
    logHead = ['x', 'y = k*x + b', 'y округлённое'];
    if (logging) logNote = 'k = ' + k.toFixed(3) + ', b = ' + b.toFixed(3);
    for (let x = x1; x !== x2 + step; x += step) {
      const y = k * x + b;
      pixels.push({ x: x, y: round(y), a: 1 });
      if (logging) addRow(x, y.toFixed(3), round(y));
    }
  } else {
    const k = dx / dy;
    const b = x1 - k * y1;
    const step = dy > 0 ? 1 : -1;
    logHead = ['y', 'x = k*y + b', 'x округлённое'];
    if (logging) logNote = 'k = ' + k.toFixed(3) + ', b = ' + b.toFixed(3);
    for (let y = y1; y !== y2 + step; y += step) {
      const x = k * y + b;
      pixels.push({ x: round(x), y: y, a: 1 });
      if (logging) addRow(y, x.toFixed(3), round(x));
    }
  }
  return pixels;
}


// 2.Алгоритм ЦДА
function dda(x1, y1, x2, y2) {
  const pixels = [];
  const dx = x2 - x1;
  const dy = y2 - y1;
  const L = Math.max(Math.abs(dx), Math.abs(dy));
  if (L === 0) {
    pixels.push({ x: x1, y: y1, a: 1 });
    return pixels;
  }

  const xInc = dx / L;
  const yInc = dy / L;
  logHead = ['шаг', 'x', 'y', 'x округлённое', 'y округлённое'];
  if (logging) logNote = 'L = ' + L + ', xInc = ' + xInc.toFixed(3) + ', yInc = ' + yInc.toFixed(3);

  let x = x1;
  let y = y1;
  for (let i = 0; i <= L; i++) {
    pixels.push({ x: round(x), y: round(y), a: 1 });
    if (logging) addRow(i, x.toFixed(3), y.toFixed(3), round(x), round(y));
    x += xInc;
    y += yInc;
  }
  return pixels;
}


// 3.Алгоритм Брезенхема (отрезок)
function bresenham(x1, y1, x2, y2) {
  const pixels = [];
  let dx = Math.abs(x2 - x1);
  let dy = Math.abs(y2 - y1);
  const sx = x2 > x1 ? 1 : -1;
  const sy = y2 > y1 ? 1 : -1;
  const steep = dy > dx;
  if (steep) {
    const t = dx;
    dx = dy;
    dy = t;
  }

  let e = 2 * dy - dx;
  let x = x1;
  let y = y1;
  logHead = ['x', 'y', 'E', 'следующий шаг'];
  if (logging) logNote = 'Dx = ' + dx + ', Dy = ' + dy + ', E = 2*Dy - Dx = ' + e;

  pixels.push({ x: x, y: y, a: 1 });
  for (let i = 0; i < dx; i++) {
    if (e >= 0) {
      if (logging) addRow(x, y, e, 'по диагонали');
      x += sx;
      y += sy;
      e += 2 * (dy - dx);
    } else {
      if (logging) addRow(x, y, e, 'прямо');
      if (steep) y += sy; else x += sx;
      e += 2 * dy;
    }
    pixels.push({ x: x, y: y, a: 1 });
  }
  if (logging) addRow(x, y, '', 'конец');
  return pixels;
}


// 4.Алгоритм Брезенхема (окружность)
function bresenhamCircle(x0, y0, r) {
  const all = [];
  let x = 0;
  let y = r;
  let e = 3 - 2 * r;
  logHead = ['x', 'y', 'E', 'следующий пиксель'];
  if (logging) logNote = 'E = 3 - 2R = ' + e + '. x и y считаются от центра.';

  while (x <= y) {
    const pts = [[x, y], [y, x], [-x, y], [-y, x], [x, -y], [y, -x], [-x, -y], [-y, -x]];
    for (const p of pts) {
      all.push({ x: x0 + p[0], y: y0 + p[1], a: 1 });
    }
    if (e >= 0) {
      if (logging) addRow(x, y, e, '(x+1, y-1)');
      e += 4 * (x - y) + 10;
      x++;
      y--;
    } else {
      if (logging) addRow(x, y, e, '(x+1, y)');
      e += 4 * x + 6;
      x++;
    }
  }

  const seen = new Set();
  return all.filter(function (p) {
    const key = p.x + ',' + p.y;
    if (seen.has(key)) return false;
    seen.add(key);
    return true;
  });
}


// 5. Алгоритм Кастла-Питвея
function reverse(s) {
  return s.split('').reverse().join('');
}

function castlePitteway(x1, y1, x2, y2) {
  const pixels = [];
  const dx = Math.abs(x2 - x1);
  const dy = Math.abs(y2 - y1);
  const sx = x2 > x1 ? 1 : -1;
  const sy = y2 > y1 ? 1 : -1;
  const steep = dy > dx;
  const a = steep ? dy : dx;
  const b = steep ? dx : dy;

  let word = '';
  logHead = ['x', 'y', 'm1', 'm2'];
  if (b === 0) {
    word = 's'.repeat(a);
  } else if (a === b) {
    word = 'd'.repeat(a);
  } else {
    let x = a - b;
    let y = b;
    let m1 = 's';
    let m2 = 'd';
    if (logging) addRow(x, y, m1, m2);
    while (x !== y) {
      if (x > y) {
        x = x - y;
        m2 = m1 + reverse(m2);
      } else {
        y = y - x;
        m1 = m2 + reverse(m1);
      }
      if (logging) addRow(x, y, m1, m2);
    }
    word = (m2 + reverse(m1)).repeat(x);
  }
  if (logging) logNote = 'a = ' + a + ', b = ' + b + '. Слово: ' + (word.length > 60 ? word.slice(0, 60) + '...' : word);

  let x = x1;
  let y = y1;
  pixels.push({ x: x, y: y, a: 1 });
  for (const letter of word) {
    if (letter === 'd') {
      x += sx;
      y += sy;
    } else if (steep) {
      y += sy;
    } else {
      x += sx;
    }
    pixels.push({ x: x, y: y, a: 1 });
  }
  return pixels;
}


// 6. Алгоритм Ву (сглаживание)
function wu(x1, y1, x2, y2) {
  const pixels = [];
  const steep = Math.abs(y2 - y1) > Math.abs(x2 - x1);

  let ax = x1, ay = y1, bx = x2, by = y2;
  if (steep) {
    ax = y1; ay = x1; bx = y2; by = x2;
  }
  if (ax > bx) {
    let t = ax; ax = bx; bx = t;
    t = ay; ay = by; by = t;
  }

  const gradient = bx === ax ? 0 : (by - ay) / (bx - ax);
  logHead = ['t', 'u', 'floor(u)', 'f', 'яркость нижнего (1-f)', 'яркость верхнего (f)'];
  if (logging) logNote = 'gradient = ' + gradient.toFixed(3) + (steep ? '. Отрезок крутой: t это y, u это x.' : '. t это x, u это y.');

  for (let t = ax; t <= bx; t++) {
    const u = ay + gradient * (t - ax);
    const low = Math.floor(u);
    const f = u - low;
    addPixel(t, low, 1 - f);
    addPixel(t, low + 1, f);
    if (logging) addRow(t, u.toFixed(3), low, f.toFixed(3), (1 - f).toFixed(3), f.toFixed(3));
  }

  function addPixel(t, u, brightness) {
    if (brightness < 0.000001) return;
    if (steep) pixels.push({ x: u, y: t, a: brightness });
    else pixels.push({ x: t, y: u, a: brightness });
  }
  return pixels;
}


if (typeof module !== 'undefined') {
  module.exports = { stepByStep, dda, bresenham, bresenhamCircle, castlePitteway, wu };
}
