console.log('Happy developing ✨')

const state = {
    rgb: {r:0, g:255, b: 0},
    cmyk: { c: 0, m: 0.1, y: 0.5, k: 0 },
    hls:  { h: 30, l: 0.5, s: 1 },
};

function value(h, m1, m2) {
    if (h < 0) h += 360;
    if (h >= 360) h -= 360;

    if (h < 60)  return m1 + (m2 - m1) * h / 60;
    if (h < 180) return m2;
    if (h < 240) return m1 + (m2 - m1) * (240 - h) / 60;
    return m1;
}

function rgbToCmyk({r,g,b}){
    let k = Math.min(1-r/255,1-g/255, 1-b/255)
    if(k === 1) return {c:0,m:0,y:0,k:1}
    let c = (1 - r/255 - k)/(1-k)
    let m = (1 - g/255 - k)/(1-k)
    let y = (1 - b/255 - k)/(1-k)
    return {c,m,y,k}
}

function cmykToRgb({c,m,y,k}){
    let r = 255*(1-c)*(1-k)
    let g = 255*(1-m)*(1-k)
    let b = 255*(1-y)*(1-k)
    return {r,g,b}
}

function hlsToRgb({h,l,s}){
    let m2, m1,r,g,b
    if(l < 1/2)m2 = l*(1+s)
    else m2 = l + s - l*s
    m1 = 2*l -m2
    if(s === 0){
        r = g = b = l
    }
    else{
        r = value(h+120, m1,m2)
        g = value(h, m1,m2)
        b = value(h-120, m1,m2)
    }
    r*= 255; g *=255; b *= 255
    return {r,g,b}
}

function rgbToHls({r,g,b}){
    r /= 255; g /= 255; b /= 255
    let max = Math.max(r,g,b);
    let min = Math.min(r,g,b);
    let h = 0,l,s
    l = (max+min)/2
    if(max === min){
        s = 0
    }
    else {
        let delta = max - min;
        if(l <= 1/2) s = delta/(max+min)
        else s = delta/(2 - max -min)
        if (max === r) h = (g-b)/delta
        else if(max === g) h = 2 + (b-r)/delta
        else h = 4 +(r-g)/delta
        h = 60*h
        if(h < 0) h += 360
    }
    return {h,l,s}
}
